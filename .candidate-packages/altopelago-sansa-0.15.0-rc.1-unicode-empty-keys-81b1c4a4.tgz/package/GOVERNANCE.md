# Governance

This repository is maintained under a single-maintainer model.

## Maintainer model

- the `sansa` implementation surface is maintained by one primary maintainer
- roadmap, release, and merge authority stay with the maintainer
- public visibility does not imply shared governance

## Contribution model

- the source may be published publicly
- outside code contributions are not part of the default workflow
- pull requests should not be assumed to be accepted or reviewed as a normal
  governance path
- changes are maintained directly by the maintainer unless an invited
  collaboration is made explicit
- forks, independent implementations, downstream tooling, and ecosystem
  experiments are encouraged
- alternate implementations should track the published specification and
  conformance authority surfaces where applicable

## Authority boundaries

- implementation authority for this JavaScript package lives in this repo
- specification authority lives in `aeonite-org/aeonite-specs`
- conformance authority lives in `aeonite-org/aeonite-cts`
- host implementations decide which SANSA surfaces and semantics they expose

## Practical expectation

The public `sansa` repo should be readable, stable, and honest about its
maintenance model. It should not imply an open contribution process that the
project does not intend to run.
