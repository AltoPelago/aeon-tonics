# SANSA Parser API Contract

Status: implementation contract for the address parser/model, resolver, query clause parser/model, query expression parser/model, bounded query evaluator, experimental instruction parse/lower/plan bridge, experimental mutation-plan API, experimental workbench mutation-policy plan filter, and standalone query/instruction tooling slices.

The parser validates SANSA address syntax and returns a structural model. The resolver applies the parsed selector model to a host-supplied namespace adapter. The query parser validates the SANSA.Query clause and expression surfaces and returns structural models. The query evaluator applies a bounded query subset over host-exposed binding metadata. The experimental instruction parser validates human-authored change intents and can lower them into structured mutation requests before handing them to the mutation planner. The experimental mutation planner constructs exact-target mutation plans, the target-surface validator checks post-plan representability, and apply runs only through host-supplied mutation hooks. Core SANSA.Mutate does not check authorization, provide transactions, decide schema legality, or assign semantics to qualifiers. The browser workbench includes a separate experimental mutation-policy plan filter for testing host-side authorization.

The implementation capability manifest is [capabilities.json](capabilities.json). It advertises `AEON.ValueSemantics`, `SANSA.Addressing`, `SANSA.Resolve`, `SANSA.Query`, Query budget controls, the experimental `validation` Query policy, experimental `SANSA.Transform` extensions, experimental `SANSA.Instruction` parsing/lowering/planning bridge behavior, an experimental `SANSA.Mutate` plan API, and the workbench-only experimental `sansa.mutate.policy.planFilter` slice.

CTS lanes:

```bash
npm run cts
npm run cts:value-semantics
npm run cts:query
npm run cts:query:experimental
npm run cts:mutate
```

The default Query CTS lane is core conformance and skips experimental extension cases. The experimental lane includes those cases for implementations that advertise matching extensions.
The value-semantics runner defaults to the mutable `value-semantics-cts-v1-snapshot-0.2` development target. It includes the minimum consumer suite plus conformance vectors for `aeon.value.radix.numeric.same-base.v1` and `aeon.value.radix.numeric.cross-base.v1`; older manifests remain selectable with `--cts <manifest>`.
The Instruction and Mutate CTS lanes are experimental and are not included in
`npm run cts` while SANSA.Instruction and SANSA.Mutate remain proposal-stage.
The Mutate lane covers structured planning, apply, target-surface checks, and
the experimental policy plan-filter boundary.
Run them explicitly with:

```bash
npm run cts:instruction
npm run cts:mutate
```

## Entry Points

```js
parseAddress(input, options?)
parseAddressOrThrow(input, options?)
parseQuery(input, options?)
parseQueryOrThrow(input, options?)
parseQueryExpression(input, options?)
parseQueryExpressionOrThrow(input, options?)
parseInstruction(input, options?)
parseInstructionOrThrow(input, options?)
lowerInstruction(input, namespaceOrOptions?, options?)
planInstruction(input, namespace, options?)
evaluateQuery(input, namespace, options?)
evaluateValueSemanticsOperation(operation, input)
resolveAddress(input, namespace, options?)
planMutation(input, namespace, options?)
applyMutationPlan(plan, namespace, options?)
renderAddress(address)
renderQuery(query)
renderQueryExpression(expression)
renderQualifierExpression(expression)
renderQualifierTerm(term)
```

`parseAddress` returns a discriminated result:

```js
{ ok: true, address }
{ ok: false, errors: [{ code, message, index }] }
```

`parseAddressOrThrow` returns `address` or throws `SansaParseError`.

`parseQuery` returns a discriminated result:

```js
{ ok: true, query }
{ ok: false, errors: [{ code, message, index }] }
```

`parseQueryOrThrow` returns `query` or throws `SansaParseError`.

`parseQueryExpression` returns a discriminated result:

```js
{ ok: true, expression }
{ ok: false, errors: [{ code, message, index }] }
```

`parseQueryExpressionOrThrow` returns `expression` or throws `SansaParseError`.

`parseInstruction` returns a structural `SansaInstruction` model:

```js
{ ok: true, instruction }
{ ok: false, errors: [{ code, message, index }] }
```

`parseInstructionOrThrow` returns `instruction` or throws `SansaParseError`.
Parsed instructions include `provenance.reason` for `because "..."` clauses
and `provenance.claimedAuthor` for `by "..."` clauses when present. These
fields are claimed source metadata only; they are not authorization,
authentication, signatures, or audit proof.

`lowerInstruction` accepts either an instruction string or parsed
`SansaInstruction`. Direct instructions lower without a namespace when their
targets are already absolute. Query-shaped instructions with `from` or `where`
require a host namespace so candidates can be resolved and candidate-relative
targets can become exact structured mutation requests. `require` clauses lower
to structured Mutate preconditions and are preserved for planning/apply recheck:

```js
lowerInstruction(
  "from $.inventory.items.*\nwhere .sku == \"B-200\"\nrequire .qty == 4\nreplace .qty with :int32, 10",
  namespace
)
```

Successful lowering returns one requested mutation operation, an operation list,
or a request envelope when `require` preconditions are present:

```js
{ ok: true, request, diagnostics, warnings, provenance }
{ ok: false, errors }
```

For candidate-relative instructions, each surviving candidate receives its own
precondition target. `where` filters candidates; `require` creates fail-closed
mutation guards.

`lowerInstruction` returns parsed source provenance separately from the lowered
mutation request. It does not place `because` or `by` on operation provenance,
because those clauses describe the instruction source rather than individual
mutation operations.

Instruction `append <container> with <value>` and
`append in <container> with <value>` canonicalize and lower as
`insert last in <container> with <value>`. They produce an ordinary structured
`insert` request with `placement: "last"`.

Instruction values support scalar literal families, SANSA address literals,
reference forms, and a conservative container-literal slice:

```text
:object, { enabled = true }
:list<string>, ["adapter", "driver"]
:tuple, ("sku", 7)
:node, <badge("new", 3)>
:symbol, |in review\|blocked|
```

Container literal members must recursively be instruction values. This keeps
Instruction values separate from arbitrary Query expressions.
Known datatype families in Instruction values are checked against the literal
representation family before lowering. For example, `:date, 2026-10-10` is
valid, while `:date, "2026-10-10"` is rejected as string representation with
date intent. Custom datatype expressions remain semantic intent over the chosen
literal family, such as `:brandColor, #ff00aa` or `:csv[","], "sku,name"`.

`planInstruction` preserves the same boundary, then calls `planMutation(...)`
with the lowered structured request:

```js
planInstruction(
  "from $.inventory.items.*\nwhere .sku == \"B-200\"\nreplace .qty with :int32, 10",
  namespace
)
```

Failures keep their phase:

```js
{ ok: false, phase: "lower", errors } // instruction lowering failed
{ ok: false, phase: "plan", loweredRequest, errors } // mutate planning failed
```

The phase boundary is part of the contract:

| Phase | Boundary |
| --- | --- |
| `parse` | Instruction syntax and literal payload syntax. |
| `lower` | Candidate selection and candidate-relative address resolution into exact structured requests. |
| `plan` | SANSA.Mutate structural legality against the host namespace. |
| `policy` | Trusted consumer authorization of already-planned operations. |
| `target` | Target-surface representability of planned datatype/kind/value intent. |
| `apply` | Host adapter execution of an already-planned operation against current namespace state. |

This function is a convenience bridge. Target-surface validation,
authorization, schema checks, apply, transactions, and host-specific mutation
policy remain outside Instruction and inside the consumer or mutation adapter
boundary.

Successful `planInstruction` results preserve `because` and `by` on
`plan.sourceProvenance` alongside `{ type: "SansaInstruction", source }`.
Consumers may display these fields, but must treat them as claimed source
metadata rather than trusted actor identity.

`evaluateQuery` accepts either a query string or a parsed `SansaQuery` and returns:

```js
{ ok: true, results, diagnostics }
{ ok: false, results: [], errors }
```

Experimental extensions are enabled by default when the package advertises them. Callers can disable the transform-library surface with:

```js
evaluateQuery(query, namespace, { extensions: { transform: false } })
```

Callers can also provide an exact allow-list:

```js
evaluateQuery(query, namespace, { enabledExtensions: ["sansa.transform.objectFrom"] })
```

A disabled advertised extension fails with `SANSA_QUERY_EVALUATE_UNSUPPORTED_EXTENSION` and includes the extension id in the diagnostic.

The proposal-stage validation policy can be enabled with:

```js
evaluateQuery(query, namespace, { policy: "validation" })
```

This policy rejects presentation and transform behavior before evaluation: `order by`, `offset`, `limit`, object projection expressions, and transform-library helpers. Rejections use `SANSA_QUERY_POLICY_VIOLATION` with `phase: "policy"`.

Dynamic Address values require an explicit activation policy. Trusted local
consumers may opt into unrestricted activation deliberately:

```js
evaluateQuery(query, namespace, { addressActivation: "trusted" })
```

Consumers crossing a trust boundary should instead provide a constrained
policy over parsed address structure:

```js
evaluateQuery(query, namespace, {
  addressActivation: {
    allowedRoots: ["$.contacts"],
    allowedSelectors: ["member", "position"],
    allowContextualRoot: true,
    maxAddressDepth: 4,
    maxBindings: 1
  }
})
```

Supported selector capability names are `member`, `position`, `range`,
`wildcard`, `recursive`, `pattern`, `semanticFilter`,
`representationFilter`, `attribute`, `local`, and `parent`. Omitted
`allowedSelectors` defaults to `member` and `position`. `allowedRoots` must
contain unqualified exact absolute SANSA addresses. Constrained contextual
activation also requires `allowContextualRoot: true` and an exact canonical
address on the current binding so the effective target can be checked.

No activation policy produces `SANSA_QUERY_PATH_ACTIVATION_POLICY_REQUIRED`.
Invalid host policy produces `SANSA_QUERY_PATH_ACTIVATION_INVALID_POLICY`.
Root, selector, contextual-root, parent-containment, and address-depth denial
produce `SANSA_QUERY_PATH_ACTIVATION_DENIED`. Exceeding `maxBindings` produces
`SANSA_QUERY_PATH_ACTIVATION_BINDING_LIMIT_EXCEEDED` and no partial query
result. Reading the binding that stores an Address value never grants authority
to resolve that address.

Query evaluation budgets are optional and fail closed:

```js
evaluateQuery(query, namespace, {
  budget: {
    maxFromBindings: 100000,
    maxWhereCandidates: 100000,
    maxOrderCandidates: 100000,
    maxResultRecords: 10000
  }
})
```

Budget exhaustion returns `SANSA_QUERY_BUDGET_EXCEEDED` with `phase`, `budget`, `limit`, and `observed`. It never implicitly truncates the Binding Set or returns partial results.

The standalone query CLI exposes these budgets as `--max-from-bindings`, `--max-where-candidates`, `--max-order-candidates`, and `--max-result-records`. The browser workbench exposes the same four limits as optional evaluation budget fields.

The separate JavaScript `evaluateAeonicComparison` and
`evaluateAeonicComparisonText` entry points implement the frozen Aeonic comparison
baseline with symbolic outcomes, strict operands, policy metadata and staged
diagnostics. See [Aeonic comparison](aeonic-comparison.md) for their request,
capability and admission contract. They do not change the historical API below
or Query's predicate behavior.

The separate JavaScript `evaluateAeonicArithmetic` and
`evaluateAeonicArithmeticText` entry points implement exact addition, subtraction,
multiplication, direct result chaining and explicit-family materialization. See
[Aeonic arithmetic](aeonic-arithmetic.md) for value/history bundles and snapshot
0.1 admission rules. This consumer capability does not add Query expression
syntax or a Rust arithmetic claim.

`evaluateValueSemanticsOperation` evaluates the Shared AEON Value Semantics minimum consumer operation shape used by the CTS scaffold:

```js
evaluateValueSemanticsOperation("equal", {
  left: { category: "finiteNumber", value: "42" },
  right: { category: "finiteNumber", value: "42" }
})

evaluateValueSemanticsOperation("compare", {
  left: { category: "negativeInfinity" },
  right: { category: "finiteNumber", value: "0" }
})

evaluateValueSemanticsOperation("isValue", {
  value: { category: "string", value: "active" }
})

evaluateValueSemanticsOperation("compare", {
  left: { category: "string", value: "éclair" },
  right: { category: "string", value: "zebre" }
}, {
  valueSemantics: createFrenchValueSemanticsProfile()
})
```

The supported operations are `equal`, `notEqual`, `compare`, `isValue`,
`radixScale`, and `temporalRelation`. `temporalRelation` returns `equal`,
`before`, `after`, `contains`, `containedBy`, `overlaps`, or `incomparable` for
two temporal claims. It treats reduced precision as a completion set and fails
closed where chronology requires an external timezone, timescale, local-clock,
or leap-second authority. The supported minimum-profile categories are `finiteNumber`, `positiveInfinity`, `negativeInfinity`, `nan`, `string`, `boolean`, `toggle`, `hex`, `radix`, `encoding`, `separator`, `symbol`, `sansaAddress`, `referenceForm`, `temporal`, `lexicalStructuredScalar`, `explicitNull`, `explicitAbsence`, `missing`, `container`, and `bindingSet`.

`finiteNumber` descriptor values may be canonical AEON numeric strings or host
numbers. Canonical strings are compared exactly, including integer, fractional,
and exponent forms, without conversion through a host floating-point type.
Namespace adapters should expose canonical source text through
`numericLexeme(binding)` or `binding.numericLexeme`; this lexeme takes
precedence over a convenience host value during comparison.

The radix family remains representation-preserving in the minimum profile.
In particular, `decimal` is the AEON `radix[10]` alias, so numeric conversion
or ordering for `%19.9900` requires an explicit trusted profile rather than an
implicit finite-number coercion.

`createRadixNumericValueSemanticsProfile()` (profile id
`aeon.value.radix.numeric.same-base.v1`, compact alias `radix-numeric`) enables
exact numeric equality and ordering for radix-family values whose resolved
bases match. A typed operand supplies the base for an untyped `%...` query
literal, so a `decimal` binding can be compared with `%19.99`. If both operands
declare different bases, comparison fails closed; cross-base rational
comparison is not part of this profile. `compareExactRadixValues(left, right,
base)` exposes the same base-2-through-base-64 comparator directly. Neither API
converts through JavaScript `number`.

`createCrossBaseRadixNumericValueSemanticsProfile()` (profile id
`aeon.value.radix.numeric.cross-base.v1`, compact alias
`radix-numeric-cross-base`) additionally compares operands with independently
resolved bases. It represents each finite radix value as an exact integer over
an exact power-of-base denominator and cross-multiplies those values without
rounding. `compareExactCrossBaseRadixValues(left, leftBase, right, rightBase)`
exposes that comparator directly. The same-base profile continues to reject
mixed bases.

`radixScaleOf(payload, base?)` returns the represented count of fractional
radix digits, excluding visual `_` separators. The profile-independent
`radixScale` value-semantics operation and `radixScale(value)` query function
expose the same representation metadata. Thus `%19.9900` has scale 4 and
`%19.99` has scale 2 even though an applicable numeric radix profile compares
their mathematical values as equal. Namespace adapters may expose a cached
`radixScale` property or callback; SANSA otherwise derives it from a radix
binding's preserved payload. Scale counts digits in each value's own base and
does not itself define cross-base quantum, rounding, or schema policy.

The default exported profile, `aeonValueSemanticsDefaultProfile`, uses Unicode scalar-value string order and deterministic default Unicode case mapping. It does not perform natural numeric-region ordering: `part-10` sorts before `part-2` under the default profile. `createIntlValueSemanticsProfile(...)` creates an explicit Intl-backed string profile, `createFrenchValueSemanticsProfile(...)` is a convenience profile for French collation and case mapping, `createNaturalAsciiValueSemanticsProfile(...)` is an exploratory deterministic numeric-region profile where `part-2` sorts before `part-10`, `createRadixNumericValueSemanticsProfile(...)` adds exact same-base radix comparison, and `createCrossBaseRadixNumericValueSemanticsProfile(...)` adds exact rational comparison across bases. Query evaluation accepts the same profile surface through `evaluateQuery(..., { valueSemantics })`.

Custom profile objects must provide a complete string contract: `compareStrings`, `lowerString`, and `upperString` together. They may also provide `compareTemporal` for temporal comparison and `compareRadix` for explicitly enabled radix comparison. Partial string hook objects are rejected rather than merged with defaults, because mixed collation, normalization, and case-mapping rules would create an implicit profile that is not portable. The minimum profile does not apply custom string collation to `hex`, `radix`, `encoding`, `separator`, `symbol`, or `sansaAddress` as domain semantics; those families keep their deterministic payload or address-expression behavior unless an explicit profile defines a richer domain.

`resolveAddress` accepts either an address string or a parsed `SansaAddress` and returns:

```js
{ ok: true, bindings, diagnostics }
{ ok: false, bindings: [], errors }
```

Parse errors are returned through the same `ok: false` shape. Normal no-match resolution returns `ok: true` with an empty `bindings` array.

Resolve distinguishes a **resolution miss** from a **resolution failure**. A miss occurs when a valid, supported selector applies to the namespace but finds no exposed structure on one or more branches; that branch contributes no bindings. A failure occurs when resolution cannot safely or validly continue, such as an unsupported selector capability, missing contextual root, forbidden boundary escape, implementation limit failure, or exact-expression multiplicity violation.

Callers may bound intermediate and final Binding Set materialization with
`maxBindings`:

```js
resolveAddress('$.inventory.**', namespace, { maxBindings: 1000 })
```

The resolver stops when the first binding beyond the limit would be retained
and returns `SANSA_RESOLVE_BINDING_LIMIT_EXCEEDED` with an empty Binding Set,
`limit`, and `observed`. Invalid limits return
`SANSA_RESOLVE_INVALID_BINDING_LIMIT`. Query dynamic-address activation maps
this bounded failure to
`SANSA_QUERY_PATH_ACTIVATION_BINDING_LIMIT_EXCEEDED`.

Resolve invariants:

- Selectors are applied left to right.
- Each selector consumes and produces an ordered Binding Set.
- Current bindings are processed in Binding Set order.
- Per-binding results are appended in deterministic local structural order.
- Resolve does not implicitly deduplicate bindings; repeated traversal routes may produce repeated binding occurrences.
- Resolve returns the original host bindings rather than reconstructed copies. Opaque occurrence metadata such as an AES `identity` is therefore preserved, but selectors, ordering, multiplicity, and canonical addresses never derive from that identity.
- A supported selector that is structurally inapplicable to one input binding produces no bindings for that branch.
- Unsupported or forbidden operations fail explicitly.
- Every output binding is expected to retain a canonical address when the host adapter exposes one.
- An exact expression must not produce more than one binding; multiplicity violations fail with `SANSA_RESOLVE_EXACT_MULTIPLICITY_VIOLATION`.
- Resolve performs no value evaluation, predicate evaluation, projection, sorting, slicing, aggregation, or mutation.

## Experimental Mutate API

`planMutation` accepts a structured mutation request, a namespace adapter, and optional resolve options. It returns an immutable mutation plan or explicit planning diagnostics:

```js
planMutation({ op: "replace", target: "$.inventory.sku", value: "B-200" }, namespace)

planMutation([
  { op: "create", parent: "$.inventory", name: "status", value: "active" },
  { op: "remove", target: "$.inventory.oldStatus" }
], namespace)
```

Supported operation requests are `create`, `replace`, `remove`, `insert`, and `move`.

Structured requests may include read-only preconditions:

```js
planMutation({
  operations: [
    { op: "replace", target: "$.inventory.sku", value: "B-200" }
  ],
  preconditions: [
    { expression: "$.inventory.sku == \"A-100\"" },
    { target: "$.inventory.sku", expression: ". == \"A-100\"" }
  ]
}, namespace)
```

Preconditions use the SANSA.Query expression evaluator and must produce a Boolean value. A failed, invalid, or non-Boolean precondition prevents plan construction and produces no executable plan. Preconditions are evaluated during planning against the same host-exposed namespace state as target resolution.

Preserved preconditions are rechecked by default before apply invokes any mutation hook. This protects a plan from non-target state drift between planning and apply. Callers that rely on a stronger external transaction or namespace-state contract may pass `{ recheckPreconditions: false }` to `applyMutationPlan`.

Request envelopes support only `operations`, `preconditions`, and `provenance`.
Known operation requests support only their operation fields plus optional inert
`provenance`. Unsupported request or operation fields fail closed rather than
being ignored. Successful planning preserves request `provenance` as plan-level
`sourceProvenance` for audit and diagnostics. Individual requested operations
may also carry `provenance`, which is preserved on the planned operation.
Provenance is inert metadata; it is not interpreted as SANSA source,
authorization policy, validation policy, or mutation rewrite behavior.

`create`, `replace`, and `insert` requests may include optional `datatype` and `kind` strings. `datatype` preserves semantic type intent, such as `sansa`, `list<string>`, or a custom type like `brandColor`. `kind` preserves representation or literal-family intent, such as `hex`, `separator`, `symbol`, `object`, `list`, `tuple`, or `node`. The planner validates only that provided hints are non-empty strings and preserves them on the planned operation. It does not decide whether the value is legal for that datatype or kind; schema, host adapters, or higher-level profiles own semantic compatibility checks.

Structured Mutate requests intentionally preserve `datatype` and `kind`
separately until target-surface validation. This differs from SANSA
Instruction syntax, where known datatype/literal-family mismatches are rejected
during instruction parsing because the author has supplied a single literal
form. A structured request may carry `datatype: "brandColor", kind: "hex"` as
valid custom intent; an AEON target surface may reject `datatype: "number",
kind: "string"` because both families are known and incompatible for AEON
materialization.

The workbench AEON adapter uses these hints when rendering Source Result output. If `kind` is present, it chooses the representation. Otherwise the adapter infers representation from known `datatype` values, then from the JSON value shape:

```js
planMutation({
  op: "create",
  parent: "$.types",
  name: "brand",
  datatype: "brandColor",
  kind: "hex",
  value: "ff00aa"
}, namespace)
```

If mutation targets or addresses embedded in precondition expressions parse successfully but produce SANSA portability warnings, successful planning preserves those diagnostics on `plan.portabilityWarnings`. For example, a caller may raise the local position-index limit above the SANSA portable ceiling; if the address resolves successfully, the plan remains inspectable but carries the non-portability warning. Pre-parsed target addresses are rendered and revalidated under the planner's configured Address ceiling, so they cannot bypass its limit or warning behavior.

Mutation plans are current-process execution artifacts, not portable serialized plan documents. A plan retains live binding objects supplied by the resolver, along with local adapter artifacts such as `bindingHandle` and `observedState`. These fields are for same-process continuity checks and diagnostics. Do not `JSON.stringify` a plan and replay it later or in another implementation; cloned or serialized plans cannot prove live binding continuity and should fail apply-time stale-target checks. A portable mutation-plan serialization format may be defined by a later profile.

For scalar values, the workbench adapter treats `kind` as the AEON literal family when one is provided. Known scalar families include `string`, `number`, `boolean`, `toggle`, `hex`, `radix`, `encoding`, `separator`/`sep`, `symbol`, `sansa`, `date`, `time`, `datetime`, `wtc`, `null`, `nan`, `infinity`, `cloneReference`, and `pointerReference`. JSON payloads omit AEON sigils: `kind: "hex"` with `"ff00aa"` renders `#ff00aa`; `kind: "sep"` with `"0.11.0"` renders `^0.11.0`; `kind: "symbol"` with `"in review|blocked"` renders `|in review\|blocked|`; `kind: "null"` with `"notApplicable"` renders `!notApplicable`; and `kind: "cloneReference"` with `"target"` renders `~target`. Symbol payloads must be non-empty. The adapter rejects payloads that cannot be rendered as the requested known AEON literal family. Unknown custom `kind` values remain adapter-visible metadata and are not interpreted by the core planner.

The AEON target accepts custom semantic datatypes over symbol representation,
such as `datatype: "workflowStage", kind: "symbol"`. The reserved `symbol`
datatype follows the GP profile's no-clarifier rule, so bracket metadata such as
`symbol["workflow"]` is rejected rather than treated like separator metadata.

Experimental Mutate budgets are optional and fail closed:

```js
planMutation(request, namespace, {
  budget: {
    maxOperations: 100,
    maxPreconditions: 20,
    maxValueNodes: 1000,
    maxValueDepth: 32,
    maxStringLength: 65536
  }
})

applyMutationPlan(plan, namespace, {
  budget: {
    maxOperations: 100,
    maxPreconditions: 20,
    maxValueNodes: 1000,
    maxValueDepth: 32,
    maxStringLength: 65536
  }
})
```

Budget exhaustion returns `SANSA_MUTATE_BUDGET_EXCEEDED` with `phase`, `budget`, `limit`, and `observed`. It does not produce a partial plan and does not apply partial mutations.

Query preconditions also inherit the planner's Resolve `maxBindings` ceiling.
The Rust planner applies a fail-closed default of `100000` bindings when the
caller does not provide a stricter ceiling. Exhausting this resolution budget
is normalized as `SANSA_MUTATE_BUDGET_EXCEEDED` with `budget: "maxBindings"`
and the failing precondition index.

`maxValueNodes`, `maxValueDepth`, and `maxStringLength` are budgets over supplied values for `create`, `replace`, and `insert`. They are honored during planning and again during apply when callers provide a prebuilt plan. `maxValueNodes` counts all supplied value nodes across the request or plan; arrays and objects count as one node plus their entries. `maxValueDepth` is the deepest supplied value tree, with scalar values at depth `1`. `maxStringLength` is the longest supplied string payload observed by this implementation.

Planning is side-effect free. Every executable target is resolved exactly at planning time. Expanded selectors such as `$.items.*`, ranges such as `$.items[0..2]`, filters, name patterns, and parent traversal are not accepted as mutation targets in this initial slice. `create` targets an existing exact parent and carries the new child name separately.

The Rust runtime exposes post-plan target validation separately through
`mutate_target::validate_mutation_plan_target`. Its built-in proposal-stage
surfaces cover AEON and JSON representability and are exercised directly by all
36 target-validation cases in the pinned experimental CTS snapshot.
`MutationTargetValidator` permits a host-defined immutable plan validator, but
successful representability does not imply schema validity, authorization, or
permission to apply the plan.

`applyMutationPlan` applies an already planned mutation only when the namespace exposes matching mutation hooks:

```js
const result = applyMutationPlan(plan, namespace, { requireAtomic: true })
```

Mutation hooks may live under `namespace.mutate`:

```js
{
  root,
  children(binding),
  parent(binding),
  bindingHandle?(binding),
  observedState?(binding),
  mutate: {
    supportsCreate: true,
    supportsReplace: true,
    supportsRemove: true,
    supportsOrderedInsert: true,
    supportsMove: true,
    supportsStableBindingIdentity: true,
    supportsAtomicApply: true,
    sameBinding?(left, right),
    create(parent, name, value, operation),
    replace(target, value, operation),
    remove(target, operation),
    insert(container, placement, value, operation),
    move(source, container, placement, operation)
  }
}
```

When an operation capability flag is omitted, this implementation infers support from the corresponding mutation hook. When an operation capability flag is explicitly `false`, apply rejects that operation before invoking hooks. `supportsAtomicApply` is only required when callers pass `{ requireAtomic: true }`.

Mutation hooks receive the planned operation as their final argument. Adapters that need to materialize host-specific values should read preserved fields such as `datatype`, `kind`, and `provenance` from that operation rather than inferring intent from the raw JSON value alone.

The conservative planner rejects structurally incompatible mutation targets before invoking adapter hooks. `create` requires a parent binding whose exposed representation or semantic type is a container. `insert` and `move` require an ordered container (`list`, `tuple`, or `node`). Scalar bindings are not treated as mutation containers merely because a resolver exposes an empty child list for uniform traversal.

Attributes are created by targeting the owner's attribute space as the create parent. For example, creating `status` under `$.types.color.@` produces the attribute path `$.types.color.@.status` and renders in AEON as an inline attribute on `color`. Attribute-space parents are valid create containers, but they are not ordered containers for `insert` or `move`.

The workbench AEON adapter materializes JSON values according to container `kind` or known container `datatype` hints. JSON objects create object bindings, JSON arrays create list bindings by default, `kind: "tuple"` or `datatype: "tuple"` renders an array as a tuple, and `kind: "node"` or `datatype: "node"` accepts a node payload with a tag and ordered children:

```json
{
  "op": "create",
  "parent": "$.types",
  "name": "badge",
  "datatype": "node",
  "value": {
    "tag": "badge",
    "children": ["new", 3]
  }
}
```

Because Source Result output is AEON, the workbench adapter rejects JSON payloads that cannot be rendered as legal AEON. Ordinary object member and node attribute names may be empty strings and retain normal uniqueness rules. Missing or nonstring names and malformed node payloads fail before any mutation is applied; node tags retain their nonempty requirement.

The planner retains the in-process binding object, canonical address, optional `bindingHandle`, and optional `observedState`. `binding`, `bindingHandle`, and `observedState` are local namespace-adapter artifacts; they are not SANSA wire-format fields. Before apply, the implementation resolves each exact address again and rejects stale targets if the resolved binding no longer matches the planned binding identity. This protects positional addresses such as `$.items[2]` from silent index drift. Ordered `insert` and `move` anchors are checked with the same stale-target rule before their hooks run.

Successful apply returns one result record per applied operation. Result records expose stable mutation-intent addresses such as `targetAddress`, `parentAddress`, `containerAddress`, `sourceAddress`, and `anchorAddress` when those roles exist. They also expose `previousAddress`, `affectedAddress`, and `resultingAddress` where known. `remove` reports the removed binding as affected, but does not invent a `resultingAddress` unless the adapter explicitly supplies one.

If a mutation hook rejects or throws during consumer-selected non-atomic apply, the result is `ok: false` with `SANSA_MUTATE_APPLY_FAILED`. `operationResults` may contain records for hooks that already completed before the failure. This must not be interpreted as full plan success; rollback, transactionality, retries, and compensation remain adapter or consumer responsibilities.

The Mutate Workbench JSON response includes a compact `affectedBinding` summary for each applied operation. It preserves `identity`, `semanticType`, split `datatype` / `generics` / `clarifiers`, `representationKind`, `scalarKind`, `nullReason`, `nodeTag`, `origin`, `span`, and a JSON-safe `value` where available, so tools can inspect applied literal-family and portable AES metadata without parsing the rendered Source Result text. Fields unavailable on a host binding remain absent.

This API does not authorize operations, validate proposed values against
schemas, follow references implicitly, or provide storage transactions.
Externally selected AEOS schemas or domain validators may check proposed-state
legality; authorization remains with the consumer, ASP, application, or adapter
boundary. See [mutate-policy.md](mutate-policy.md) for the separate workbench
policy prototype that exercises this boundary.

Parent traversal defaults to the conservative structural model: traversal from the effective resolution root resolves to an empty Binding Set. The effective resolution root is the root binding established by `$`, `?`, or the root of a dynamic resolution context for the current branch. Callers that need stricter boundary diagnostics can pass:

```js
resolveAddress('?.^', namespace, {
  contextualRoot,
  failOnParentFromEffectiveRoot: true
})
```

This reports `SANSA_RESOLVE_BOUNDARY_ESCAPE_FORBIDDEN` instead of an empty Binding Set. Callers that forbid parent traversal entirely can pass:

```js
resolveAddress('$.items[0].^', namespace, {
  parentTraversal: 'forbid'
})
```

This reports `SANSA_RESOLVE_PARENT_TRAVERSAL_FORBIDDEN`, distinct from `SANSA_RESOLVE_UNSUPPORTED_PARENT`, which means the namespace adapter does not expose parent traversal.

Query evaluation diagnostics include query context when available:

```js
{
  code,
  message,
  phase,
  candidateAddress,
  extension,
  budget,
  limit,
  observed
}
```

`phase` is one of `parse`, `policy`, `from`, `where`, `order`, or `select`. `candidateAddress` is present when the failure occurs while evaluating a specific candidate binding. `extension` identifies disabled or unsupported extension surfaces. `budget`, `limit`, and `observed` identify budget exhaustion context.

## Command Line Tool

The package exposes `sansa-query` and the local `npm run query` script. The tool is intended for development fixtures and language exploration rather than host integration.

```bash
npm run query -- --query 'from $.inventory.items.* where .qty >= 2 select .sku'
npm run query -- --mode parse --format json --query 'from $.inventory.items.* select .sku'
npm run query -- --policy validation --query 'from $.inventory.items.* where .qty >= 4 select .sku'
npm run query -- --disable-transform --query 'from $.table.content.* select objectFrom($.table.header.*, .*)'
npm run query -- --params '{"source":{"type":"SansaAddressLiteral","address":"$.inventory.items[3]"},"field":{"type":"SansaAddressLiteral","address":"?.sku"}}' --query 'from path($.<"params">.source) select path($.<"params">.field)'
```

Evaluate-mode text output renders values in an AEON-like display form. Strings remain quoted, constructed objects render compactly, and explicit null bindings with a surfaced `nullReason` render as `!reason`, for example `!notSet`. JSON output is unchanged and remains the stable structured result envelope for tooling.

Options:

- `--query`, `-q`: query source
- `--query-file`: read query source from a file
- `--fixture`, `-f`: AEON, Telex AES, Film AES, or JSON namespace fixture, defaulting to `fixtures/query-inventory.json`
- `--fixture-kind`: force fixture kind as `aeon`, `telex`, `film`, or `json`; otherwise inferred from the file extension
- `--params`: JSON params mounted at `$.<"params">`
- `--params-file`: read JSON params from a file and mount them at `$.<"params">`
- `--mode`: `evaluate` or `parse`
- `--format`: `text` or `json`
- `--policy`: optional query policy, currently `validation`
- `--disable-transform`: disable experimental `SANSA.Transform` helpers during evaluation
- `--max-from-bindings`: fail if the from source resolves more than this many bindings
- `--max-where-candidates`: fail if where would evaluate more than this many candidates
- `--max-order-candidates`: fail if order by would sort more than this many candidates
- `--max-result-records`: fail if select would produce more than this many result records

The default CLI fixture is JSON so `sansa-query` can run without optional host integrations after package install. AEON fixtures are compiled with an optional AEON TypeScript Core runtime and adapted into a SANSA resolver namespace. Telex fixtures use an optional AEON AES runtime and adapt complete portable records directly, preserving flat attributes, structural identities, datatype components, record order, and expanded node heads. Film fixtures are read as bytes, decoded by the same optional AES runtime, and passed through that portable-record adapter. Telex and Film partial streams require external state and are rejected. Film support is reader-only: the query tool does not mutate, re-encode, or provide a durable Film writer. JSON fixture bindings remain host-neutral objects. The built-in JSON adapter reads `root`, `children`, `attributeSpace` or `attributes`, `localSpaces`, and scalar values through `value` or `scalar`.

AEON fixture support is optional. The tool resolves AEON Core from `SANSA_AEON_CORE_MODULE`, from an installed `@altopelago/aeon-core` visible to the calling project, or from the sibling aeon-family development workspace path. Telex and Film support resolve the AES codec from `SANSA_AEON_AES_MODULE`, an installed `@altopelago/aeon-aes`, or the corresponding sibling development build. JSON fixtures and Query parsing require neither runtime.

Params may be supplied either as a full local-space fixture binding with `children`, or as a simple object map. Structured SANSA Address Literal values use `{ "type": "SansaAddressLiteral", "address": "..." }`; these are preserved as `sansa` bindings so query expressions can activate them with `path(...)`.

The package also includes a browser workbench:

```bash
npm run query:web
```

The workbench server serves [tools/query-web](../tools/query-web) and [tools/mutate-web](../tools/mutate-web). The Query Workbench defaults to `.aeon` source input and exposes a local `/api/query` endpoint. For `.aeon` source, the endpoint uses the optional AEON TypeScript core compiler to derive a host-neutral SANSA resolver namespace before running SANSA.Query. Its Telex mode consumes a complete portable AES stream directly, while JSON fixture mode remains available for resolver-shape debugging. A params editor mounts a small AEON source snippet as `$.<"params">`; top-level params bindings become children of that local address space. The browser UI includes a Normal/Validation policy toggle, a Transform extension toggle, and evaluation budget inputs. `/api/query` accepts `sourceKind: "aeon" | "telex" | "json"`, `policy: "validation"`, `transformExtensions: false`, and `budget` for evaluate requests. Film remains available to the CLI and to direct `evaluateQueryForWorkbench(...)` callers that can supply bytes; it is not accepted through the browser's JSON request envelope in this release.

The experimental Mutate Workbench exposes `/api/mutate`. It accepts `.aeon`
source or complete portable Telex AES selected with `sourceKind: "aeon" |
"telex"`, plan/apply mode, operation/precondition/value mutation budgets, parse
position-limit input, apply options such as `requireAtomic` and
`recheckPreconditions`, an optional experimental mutation policy plan filter, and one
of two request input forms:

- `requestKind: "structured"` with a structured JSON mutation request, which
  runs `planMutation(...)` directly.
- `requestKind: "instruction"` with proposal-stage SANSA Instruction source,
  which runs `planInstruction(...)` and then uses the returned plan for the
  same preview/apply path.

For AEON input, the endpoint compiles the source into a fresh host-neutral
namespace, layers an in-memory mutation adapter over that namespace, and
returns an AEON-ish rendered source tree. It is not a canonical AEON source
rewriter. For Telex input, it validates a complete stream, plans against the
portable namespace directly, and re-emits Telex after apply without creating an
AEON AST or source document.

When the experimental mutation policy plan filter is enabled, policy JSON is trusted
consumer input and is validated before authorization. Unsupported top-level or
rule fields fail with `SANSA_MUTATE_POLICY_INVALID` instead of being ignored, so
claimed provenance such as Instruction `by` metadata cannot accidentally become
policy authority.

Target representability is checked explicitly with
`validateMutationPlanTarget(plan, targetSurface)`. This API is separate from
`planMutation(...)` so mutation planning remains target-neutral:

```text
planMutation(...)
validateMutationPlanTarget(...)
applyMutationPlan(...)
```

Built-in target surfaces currently include `"aeon"`, `"json"`, and `"telex"`.
`"json-compatible"` is accepted as an alias for `"json"`; `"telex.aes"` is an
alias for `"telex"`. Callers may also pass
a custom target surface object with an `id` and `validateOperation(operation,
context)` hook. Target-surface failures are not SANSA parse or
mutation-planning failures: they mean the target format cannot represent the
planned operation. They use `phase: "target"` with codes such as
`SANSA_MUTATE_TARGET_UNSUPPORTED_DATATYPE`,
`SANSA_MUTATE_TARGET_UNSUPPORTED_FEATURE`,
`SANSA_MUTATE_TARGET_UNSUPPORTED_VALUE`, and
`SANSA_MUTATE_TARGET_UNSUPPORTED_OPERATION`.
Target-surface diagnostics should preserve `targetFormat` when known. Datatype
failures include `datatype`; value representability failures may include
`valuePath` to identify the rejected planned value position.

The Mutate Workbench uses this same API. Its `options.targetFormat` defaults to
the selected source format and can be set explicitly through the browser target
selector or the `/api/mutate` request payload.

The `/api/mutate` response includes a `targetProfile` object in JSON mode:

```json
{
  "id": "aeon",
  "boundary": "representability",
  "summary": "AEON target surface: accepts AEON-representable datatype, kind, and value intent before apply."
}
```

`targetProfile.id` is the normalized target surface used for validation, so
aliases such as `"json-compatible"` report `"json"`. `boundary:
"representability"` means the selected target surface is checking whether a
planned operation can be carried by that target format; it is not schema
approval, authorization, or mutation planning. Target-surface diagnostic text
therefore begins with a phase summary such as `target-surface: plan produced;
selected target cannot represent the planned intent for target 'aeon'`. Plan
failures use a different summary, such as `plan: mutation request could not be
planned`, so technical tests can distinguish invalid mutation intent from valid
intent rejected by the selected target surface.

For example, SANSA Instruction can parse and lower `:string<null>` as datatype
intent, but the AEON workbench target rejects it because AEON only allows
generic parameters on specific datatype families:

```text
create $.types.textProbe with :string<null>, ""
```

Structured requests reach the same target-surface boundary with separate
fields. Custom semantic intent such as `datatype: "brandColor", kind: "hex",
value: "ff00aa"` remains representable for an AEON target, while a known-family
contradiction such as `datatype: "number", kind: "string", value: "42"` is
reported as target-surface value representability failure rather than as a
planning failure.

JSON target mode accepts ordinary JSON-compatible object/list/string/number/
boolean/null values, but rejects AEON-only representational features such as
attribute-space mutations, `sansa` datatype hints, parameterized datatypes,
tuples, nodes, references, symbols, NaN, and Infinity. In particular, the
strict SANSA target surface does not silently materialize a symbol as a JSON
string; a consumer that deliberately chooses AEON's separate lossy JSON mode
owns that conversion and its warning metadata.

Telex target mode is deliberately narrower in this release. It accepts only an
exact `replace` of an existing portable scalar event with a representable
scalar value. The writer preserves record order, address, identity, datatype
components when unchanged, and all separate attribute events. An explicit new
datatype is parsed into `datatype`, `generics`, and `clarifiers` before the wire
encoder recombines it. Because `origin` and `span` identify bytes in the input
artifact, the changed event loses both fields; untouched events retain them.
Create, remove, insert, move, container replacement, node-head replacement, and
reference replacement fail at the target-surface boundary. Those operations
need an explicit portable path-reindexing/reference-translation contract before
the adapter can claim deterministic Telex output.

When the workbench policy toggle is enabled, the endpoint accepts
`options.policySource` containing a JSON policy document. The endpoint plans
first, checks the planned operations against the policy, and only applies the
plan when every operation is authorized. The current workbench policy fields
are `operation` / `operations`, `target`, `parent`, `container`, `source`,
`anchor`, `name` / `names`, `datatype` / `datatypes`, `kind` / `kinds`, and
`value` / `values`. Address-role fields are SANSA address expressions resolved
against the same namespace view as the plan; `anchor` matches only resolved
`before` / `after` placement anchors, not `first` or `last` placements.
Policy diagnostics use
`phase: "policy"` and workbench-specific codes such as
`SANSA_MUTATE_POLICY_DENIED`. Policy diagnostics may include
`operationIndex`, `ruleIndex`, `policyField`, `policyScope`, and
`policyAddress` so workbench clients can highlight the failed operation, rule,
field, matcher scope, or unsupported matcher address. This remains outside the
core planner.

Workbench responses include `text` for successful results and diagnostics. Successful parse and evaluate responses also include `inspect`, a scan-friendly diagnostic view for the browser workbench. Text mode is intended for compact inspection, Inspect mode shows candidate/value metadata, and JSON mode exposes the structured result or diagnostic payload.

Workbench example queries are defined as grouped catalog data in [tools/query-web/examples.mjs](../tools/query-web/examples.mjs). The UI renders its example menu from that module, and tests use the same catalog to keep labels, queries, and expected behavior in sync.

## Address Model

```js
{
  type: "SansaAddress",
  root,
  selectors,
  qualifierExpression,
  isExact,
  canonical
}
```

`root.kind` is `absolute` for `$` or `contextual` for `?`.

`isExact` is true only when every selector is one of:

- `member`
- `position`
- `attributeSpace`
- `localSpace`

Parent traversal, position ranges, expansion selectors, filters, and name patterns make the address expression non-exact.

## Selector Nodes

```js
{ type: "member", name, quoted }
{ type: "position", index }
{ type: "positionRange", start, end }
{ type: "parent" }
{ type: "attributeSpace" }
{ type: "localSpace", name }
{ type: "directExpansion" }
{ type: "descendantExpansion" }
{ type: "namePattern", pattern }
{ type: "semanticTypeFilter", name }
{ type: "representationKindFilter", name }
```

Selector names and patterns are decoded string values. Renderers choose the shortest unambiguous canonical form.

## Resolve Namespace Adapter

Resolve is host-adapted. A namespace must expose a root binding:

```js
{
  root,
  contextualRoot?,
  children?(binding),
  parent?(binding),
  member?(binding, name),
  position?(binding, index),
  attributeSpace?(binding),
  localSpace?(binding, name),
  name?(binding),
  index?(binding),
  semanticType?(binding),
  representationKind?(binding),
  value?(binding),
  nullReason?(binding),
  semanticTypeMatches?(binding, expected),
  representationKindMatches?(binding, expected)
}
```

For simple hosts, bindings may expose fields directly:

```js
{
  address,
  name,
  index,
  semanticType,
  datatype,
  representationKind,
  kind,
  type,
  scalarKind,
  valueKind,
  literalKind,
  nullReason,
  value,
  scalar,
  children,
  parent,
  attributeSpace,
  attributes
}
```

`scalarKind`, `valueKind`, or `literalKind` may be used by host-neutral fixtures to preserve scalar forms that JSON cannot express directly, such as `nan`, `infinity`, and explicit `null`. `nullReason` carries the surfaced AEON null reason, such as `notSet` or `notApplicable`.

Query also recognizes the portable scalar representation names directly, including
`DateLiteral`, `TimeLiteral`, `DateTimeLiteral`, `WTCDateTimeLiteral` and
`SymbolicLiteral`, whether supplied by a namespace's `representationKind()` hook
or a binding field. This internal value-family classification does not rename
the exposed representation kinds or change `%RepresentationKind` filters.

Exact member and position selectors select direct children. This implementation caps position indexes and position range endpoints at `999999`; SANSA v1 portability requires implementations to support at least one million addressable positions, expressed as indexes `0` through `999999` inclusive. Larger accepted values are implementation-defined and non-portable. Implementations that accept larger values should surface `SANSA_NON_PORTABLE_POSITION_INDEX` when their host API supports non-fatal diagnostics. Position ranges select inclusive positional children exposed by the host binding; open start means position `0`, open end means through the final exposed positional child, and reversed ranges resolve to an empty binding set. `.^` selects an exposed parent binding, resolves empty at the effective resolution root unless stricter policy is requested, and fails explicitly when parent traversal is unsupported or forbidden. `.*` returns direct children. `.**` returns descendants in deterministic preorder, excluding the current binding. Descendant expansion follows structural children only; it does not implicitly enter attribute or local address spaces. `.("pattern")` selects direct children whose binding name matches the complete glob pattern, where `?` matches one Unicode code point and `*` matches zero or more Unicode code points. Within the decoded pattern payload, `\?`, `\*`, and `\\` match literal question mark, asterisk, and backslash characters respectively. Pattern matching operates on the exact exposed binding name without normalization or locale-sensitive comparison.

`#name` filters the current binding set by semantic type. The default matcher accepts exact semantic type names and base names before `<...>` or `[...]`. `%name` filters the current binding set by representation kind.

Representation-kind names use the ordinary identifier grammar. An AES-backed namespace exposes normative AEON representation names directly, so `%NodeHead` selects node heads without a separate SANSA vocabulary. A portable `NodeLiteral` exposes its indexed `NodeHead` values as direct children, and each head exposes its indexed content as direct children: `NodeLiteral[head-index][content-index]`. It must not collapse content directly beneath the outer node. Parent traversal exposes the inverse hierarchy. SANSA traverses the structure supplied by the host adapter; AES topology validation remains the host's responsibility.

`?` uses a binding supplied through `options.contextualRoot` or `namespace.contextualRoot`. Unlike `root`, `contextualRoot` is a binding value, not a callback. Hosts that need a dynamic contextual root should resolve it before calling `resolveAddress`. Attribute and local address-space traversal are explicit transitions through `.@` and `.<"name">`. They fail explicitly unless exposed by the namespace adapter or binding model. When local-space traversal is supported but a binding does not expose the named local space, normal resolution returns an empty binding set.

Qualifiers are preserved by the parser but ignored by generic structural resolution.

## Query Parser Model

```js
{
  type: "SansaQuery",
  from,
  where,
  orderBy,
  offset,
  limit,
  select,
  clauses,
  canonical
}
```

Query parsing validates query structure and expression syntax only. It does not evaluate query expressions, resolve candidate bindings, apply filters, sort bindings, slice results, or construct projection output.

The accepted clause order is:

```text
from
where
order by
offset
limit
select
```

`from` is required and must contain either one valid SANSA address expression or a `path(...)` source expression. `select` is required and terminal. `where`, `select`, and order-key expression bodies carry both a canonical source string and an expression AST. `order by` is split into top-level keys, each with an `asc` or `desc` direction; omitted directions canonicalize to `asc`. `offset` and `limit` accept non-negative integers without leading zeroes up to this implementation's query integer cap, `9007199254740991`.

Query comments are lexical trivia:

```text
// line comment
/* block comment */
```

Comments are removed from canonical query rendering.

Query clause nodes:

```js
{ type: "fromClause", source: "address", address }
{ type: "fromClause", source: "expression", expression, ast }
{ type: "whereClause", expression, ast }
{ type: "orderByClause", keys }
{ type: "offsetClause", value }
{ type: "limitClause", value }
{ type: "selectClause", expression, ast }
```

Order keys:

```js
{ type: "orderKey", expression, ast, direction }
```

## Query Expression Model

The expression parser produces a syntax AST only. It does not assign semantic meaning to functions, compare values, collapse Binding Sets, resolve addresses, or decide whether a query is authorized.

Expression nodes:

```js
{ type: "literalExpression", kind, value, canonical }
{ type: "resolutionExpression", scope, address, canonical }
{ type: "groupExpression", expression, canonical }
{ type: "unaryExpression", operator, argument, canonical }
{ type: "binaryExpression", operator, left, right, canonical }
{ type: "functionCallExpression", name, arguments, canonical }
{ type: "existenceExpression", operator, argument, canonical }
{ type: "cardinalityExpression", operator, argument, canonical }
{ type: "projectionExpression", fields, canonical }
```

Projection fields:

```js
{ type: "projectionField", name, expression }
```

Resolution expression scopes:

- `current`: a leading dot expression such as `.name`
- `absolute`: a leading `$` SANSA address
- `contextual`: a leading `?` SANSA address

Recognized expression syntax:

- resolution expressions: `.name`, `.roles.*`, `$.users.*`, `$.<"params">.username`
- literals: double-quoted strings, numbers, `true`, `false`
- comparisons and membership: `==`, `!=`, `<`, `<=`, `>`, `>=`, `in`
- Boolean operators: `not`, `and`, `or`
- parenthesized groups
- cardinality operators: `any(...)`, `all(...)`, `none(...)`
- function-call shape: `contains(.name, "x")`
- projection shape: `{ name = .name status = .status }`

Projection fields use AEON assignment syntax. `:` is reserved for AEON
datatype annotations and is not accepted as a JSON-style field separator.

Operator precedence:

```text
parenthesized expression
not
comparison
and
or
```

## Query Evaluator

The evaluator is intentionally narrower than the query grammar. It exists to prove the parser, resolver, and expression model can execute together over host-neutral bindings.

Currently evaluated:

- `from` through SANSA Resolve or `path(...)` source activation
- `where` expressions that produce explicit Boolean values
- `order by` over string and number scalar keys
- `offset`
- `limit`
- `select` expressions
- scalar literals
- resolution expressions
- comparisons between same-type scalar values and same-kind structural containers
- membership over Binding Sets with `in`
- Boolean `not`, `and`, `or`
- existence predicates over resolution expressions: `exists`, `absent`
- cardinality predicates over resolved binding sets: `any`, `all`, `none`
- built-in string functions: `contains`, `startsWith`, `endsWith`, `lower`, `upper`, `concat`
- temporal completion-set relation function: `temporalRelation`
- dynamic address activation in expression positions with `path`
- missing-aware fallback with `fallback`
- dynamic direct-child resolution over addressable containers with `resolveChild`
- explicit read-only reference following with `follow`
- experimental transform-library object construction with `objectFrom`
- experimental transform-library field projection with `fieldsFrom`
- built-in value predicates: `isValue`, `isNull`, `isNullReason`, `isNaN`, `isInfinity`
- projection expressions

Boolean context accepts explicit Boolean scalar values and single resolved bindings that expose a Boolean scalar. It does not apply host-language truthiness to strings, numbers, nulls, objects, or Binding Sets. Boolean `not` evaluates its operand in Boolean context and returns the negated value. Boolean `and` and `or` short-circuit from left to right. `a and b` does not evaluate `b` when `a` is false; `a or b` does not evaluate `b` when `a` is true.

Membership uses comparison-style syntax but explicitly consumes the right operand as a Binding Set:

```text
where "admin" in .roles.*
```

The left operand is consumed in scalar context. Right-side bindings are evaluated in Binding Set order. Each right-side binding is consumed as a scalar and compared using equality comparison rules. Membership returns true on the first successful match and does not evaluate later bindings. Empty Binding Sets and fully evaluated non-matching sets evaluate to false. Membership does not skip incompatible bindings before a match: explicit null, NaN, missing scalar, cardinality, and mixed-type comparison failures surface as diagnostics. The right operand must evaluate to a Binding Set; string containment remains the `contains(...)` function.

Equality and inequality comparison may also consume one resolved container binding on each side. Containers compare structurally only when both sides expose the same normalized container kind (`object`, `list`, `tuple`, or `node`). Lists and tuples compare by child order; objects compare by member names and member values. Nodes compare by exposed tag, exposed attributes, and child order. Containers are not orderable by the minimum profile, and membership remains scalar-only.

Container datatype labels remain visible to semantic filters. This includes `#object`, object aliases such as `#obj`, `#o`, and `#envelope`, generic bases such as `#list` for `list<T>`, plus `#tuple` and `#node`. These filters select bindings only; they do not normalize aliases for equality, change structural comparison, or introduce container ordering.

Container representation filters such as `%object`, `%list`, `%tuple`, and `%node` select by exposed shape instead of datatype claim. For example, `%object` can select both `obj` and `envelope` bindings when both expose object representation.

Existence predicates inspect binding presence rather than scalar value:

```text
exists(.email) == true when .email resolves one or more bindings
absent(.email) == true when .email resolves zero bindings
```

Use semantic or representation filters inside the existence operand to guard later scalar comparisons:

```text
where exists(.id#number) and .id > 2
```

Without the `#number` filter, `.id > 2` may fail on a present non-number binding.

Missing bindings, explicit null values, and special numeric values are distinct:

```text
absent(.status) == true when .status resolves zero bindings
isValue(.status) == true when .status resolves one concrete value binding
isNull(.status) == true when .status resolves one explicit null binding
isNullReason(.status, "notSet") == true when the null reason matches
isNaN(.metric) == true when the scalar is explicit NaN
isInfinity(.limit) == true when the scalar is positive or negative infinity
```

`isValue(...)` is a missing-aware concrete-value guard. It returns true when its operand evaluates to one concrete value, including finite numbers, infinities, strings, Booleans, toggles, symbols, lexical structured scalars, SANSA address literals, legal reference forms, and containers. It may inspect scalar expressions directly or consume a Binding Set produced by resolution or `path(...)`. It returns false for zero bindings, explicit null, explicit absence values, and NaN. More than one binding remains a cardinality error.

`isNull(...)`, `isNullReason(...)`, `isNaN(...)`, and `isInfinity(...)` consume their first operand in single-binding scalar context. A missing operand therefore fails unless the query guards it with `exists(...)` or another missing-aware operator.

`NaN` is not comparable. Scalar comparison and ordering over `NaN` fail with `SANSA_QUERY_EVALUATE_INVALID_COMPARISON`; use `isNaN(...)` for explicit tests. Infinity values remain numeric bounds and may participate in same-type numeric comparisons and ordering.

Query source can express selected AEON scalar literal families directly:
`#ff00aa`, `%ff00aa`, `&QmFzZTY0IQ==`, `^0.11.0`, `|approved|`, `!notSet`, and
temporal-looking literals such as `2026-`, `2026-07`, `2026-07-25`, `09:30:00Z`,
`2026-07-25T09:30:00Z`, and `2026-07-25T09:30:00Z&Australia/Melbourne`. These
literals preserve their family metadata for comparison. Symbol literals use
string-style escapes plus `\|` for an embedded pipe, reject empty payloads and
raw newlines, and remain distinct from strings. Same-family temporal
literals compare through the active temporal profile; the default profile uses
canonical payload order.
Explicit null literals are tested through null predicates rather than equality.

The temporal literal boundary follows Core rather than the general-purpose
schema: year/month date ticks can compose with clocks (`2024-T10:Z`,
`2024-02T10:&Europe`), second `60` remains structurally valid, and arbitrary
authored fractional digits are preserved. WTC `local` is case-sensitive; named
contexts remain opaque ASCII payloads. Invalid fields and comment-looking
punctuation inside a contiguous WTC token are not reinterpreted as trivia.

The built-in temporal relation helper handles contiguous date extents and
complete-date clock extents. Clock-bearing year/month ticks can denote disjoint
daily sets; those comparisons currently return `incomparable` rather than
inventing a month/day or flattening the sets into a single interval. This
conservative comparison limitation does not reject the literal or its AEON
target representation. Default representation equality/order is unchanged.

AEON target validation also distinguishes reserved `base64` (decodable
Base64URL, including valid padding and zero unused tail bits) from opaque
`encoding`, `inline` and `embed` payloads. For `prose`/`trimtick`, exact multiline
values must survive Core gutter normalization: trailing newlines and nonempty
whitespace-only content lines cannot be preserved and produce a target-phase
diagnostic before apply. The workbench protects representable leading empty
lines and mixed payload indentation when re-emitting trimticks. Ordinary
quoted-string values and direct Telex string payloads retain their full domain.

These datatype-specific literal checks do not decode reference addresses as
payload data. Clone/pointer references (including native Rust reference-form
descriptors) retain address validation; `base64` describes the referred value,
not the bytes or Base64URL tail bits of its address.

Current comparison policy:

| Operands | Equality | Ordering | Result |
| --- | --- | --- | --- |
| number and number | allowed | allowed | numeric comparison |
| numeric subtype and numeric subtype | allowed | allowed | `int`, `uint`, and `float` datatype labels remain visible to semantic filters; comparison uses finite numeric values once exposed by the host |
| datatype aliases and their literal family | follows family | follows family | aliases remain visible to semantic filters: `n` as number, `bool` as Boolean, `trimtick`/`prose` as string, `radix2`/`radix6`/`radix8`/`radix12` as radix, `base64`/`embed`/`inline` as encoding, `kadot` as separator, and `obj`/`o`/`envelope` as object containers |
| string and string | allowed | allowed | Unicode scalar-value ordering |
| boolean and boolean | allowed | error | ordering emits `SANSA_QUERY_EVALUATE_INVALID_COMPARISON` |
| toggle and toggle | allowed | error | exact token equality; `yes` does not equal `on` |
| toggle and boolean | error | error | no implicit Boolean coercion |
| hex and hex | allowed | error | canonical payload identity only |
| radix and radix | allowed | error | preserved payload and radix-family metadata identity only |
| hex and radix | error | error | no implicit numeric or base-16 coercion |
| encoding and encoding | allowed | allowed | naïve payload order over preserved encoded payload characters |
| separator and separator | allowed | allowed | naïve whole-payload order; no splitting on datatype clarifiers |
| symbol and symbol | allowed | error | exact decoded payload identity; no implicit string coercion or ordering |
| SANSA address and SANSA address | allowed | allowed | canonical address-expression identity and naïve address-expression order |
| temporal and temporal | allowed within same family | allowed within same family | default profile uses canonical temporal payload order; cross-family comparison fails without explicit compatibility |
| reference form and reference form | allowed | error | reference-kind and canonical target-path identity; no implicit follow |
| explicit null | error | error | use `isNull(...)` / `isNullReason(...)` |
| NaN | error | error | use `isNaN(...)` |
| infinity and number | allowed | allowed | numeric bound comparison |
| mixed types | error | error | no implicit coercion |

Semantic filters match the base datatype label of generic claims. For example,
`#null`, `#nan`, and `#infinity` match host bindings annotated as `null<T>`,
`nan<T>`, and `infinity<T>` before value predicates inspect the scalar.

By default, this implementation slice compares strings by Unicode scalar value. It must not use natural sorting, host locale, process locale, database collation, or `localeCompare`-style host defaults unless the caller explicitly supplies a value-semantics profile such as `createNaturalAsciiValueSemanticsProfile()` or `createFrenchValueSemanticsProfile()`.

Ordinary value-producing functions evaluate their arguments before invocation. Resolution-expression arguments are consumed in single-binding scalar context:

| Argument outcome | Diagnostic |
| --- | --- |
| zero bindings | `SANSA_QUERY_EVALUATE_MISSING_SCALAR` |
| multiple bindings | `SANSA_QUERY_EVALUATE_CARDINALITY` |
| unsupported scalar type | `SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL` |

The current built-in string functions are `contains`, `startsWith`, `endsWith`, `lower`, `upper`, and `concat`. Function-name matching is case-sensitive. They require string arguments and reject explicit null, NaN, infinity, Boolean, number, object, and Binding Set arguments unless a future function contract explicitly accepts one of those forms. `radixScale(value)` accepts one radix-family scalar and returns its represented fractional digit count without normalizing trailing zeroes. `temporalRelation(left, right)` accepts two single temporal scalars and returns `equal`, `before`, `after`, `contains`, `containedBy`, `overlaps`, or `incomparable` using the completion-set semantics of the shared temporal relation operation. Year (`2026-`), month (`2026-07`), and day (`2026-07-25`) dates denote their complete calendar extents, so coarser dates can contain finer dates. Value predicates such as `isValue(...)`, `isNull(...)`, `isNullReason(...)`, `isNaN(...)`, and `isInfinity(...)` define their own argument contracts.

`path(value)` is a function-like structural operator. Its operand is consumed in scalar context and must be a structured SANSA Address Literal value. The initial representation is an object such as `{ type: "SansaAddressLiteral", address: "?.sku" }` or `{ type: "SansaAddressLiteral", address: parsedAddress }`. Plain strings are rejected and are not parsed as address syntax. In expression positions such as `select`, `where`, and `order by`, the activated address resolves in the current candidate context and returns a Binding Set. In `from path(...)`, the activated address supplies the source Binding Set for the query.

Activation is checked after the operand becomes a structured Address value and
before that address is resolved. Structural root checks do not use string
prefixes. Parent traversal is normalized for containment and fails closed when
its reach cannot be proven. The standalone CLI and browser workbench explicitly
use trusted activation because they operate as local technical test tools over
fixtures selected by the user; embedding applications must choose their own
trusted or constrained policy.

SANSA Address Literal values remain selectable as values with `#sansa` and
`%sansa`. Those filters select the literal binding itself and do not activate
the address; activation is always explicit through `path(...)`.

`fallback(primary, replacement)` is a function-like operator with lazy missing handling. The primary operand is consumed in scalar value context. If it resolves zero bindings, or raises a missing-scalar diagnostic, the replacement operand is evaluated and consumed in the same scalar value context. If the primary operand succeeds, the replacement operand is not evaluated. Explicit null values, cardinality errors, type errors, comparison errors, and unsupported-function errors do not trigger fallback.

`resolveChild(base, key)` is a function-like structural operator with a distinct argument contract. The base argument must be a resolution expression resolving exactly one addressable container. The key argument is consumed in scalar context; string keys select a direct member of the base, and non-negative integer keys select a direct positional child. A missing target returns an empty Binding Set. Multiple base bindings, multiple key bindings, unsupported key types, and multiple target bindings fail with diagnostics. It does not parse traversal strings, scan collections, or perform join semantics.

`follow(reference)` is a function-like read-only reference operator. Its operand
must evaluate to one AEON reference form. The function resolves the reference's
canonical exact target path and returns that target Binding Set. Without
`follow(...)`, references compare as reference forms by reference kind and
canonical target path; with `follow(...)`, the target binding is consumed by the
ordinary scalar, structural, or order context. `follow(...)` does not rewrite,
inline, clone, alias, or erase the source reference.

Concrete reference forms remain visible to representation filters such as
`%cloneReference` and `%pointerReference`. These filters select the reference
binding itself and do not imply `follow(...)` or materialization.

`objectFrom(keys, values)` is an experimental transform-library helper with a distinct argument contract. Both arguments must be resolution expressions. The key and value Binding Sets must have equal length. Key bindings must expose unique string scalar values. Value bindings must expose scalar values. The helper pairs keys and values by resolved order and returns one derived object. Mismatched lengths, duplicate keys, non-string keys, and non-scalar values fail with diagnostics. It is not part of the required SANSA.Query v1 core surface.

`fieldsFrom(keys, values, field, ...)` is an experimental transform-library helper. It uses the same ordered pairing model as `objectFrom`, then returns only the requested string-named fields. It is implemented for workbench and conformance experimentation, but is not part of the required SANSA.Query v1 core surface.

Cardinality predicates follow conventional quantified logic:

```text
any(empty)  = false
all(empty)  = true
none(empty) = true
```

`all(...)` therefore means every resolved binding satisfies the predicate; it does not by itself require that at least one binding exists. A non-empty all-match condition is expressed by combining `any(...)` and `all(...)`:

```text
where any(.roles.* == "admin") and all(.roles.* == "admin")
```

`only(...)` may parse as a generic function-call expression, but it is not part of the current evaluator surface. It is reserved as a possible future shorthand for the non-empty all-match pattern and currently evaluates as `SANSA_QUERY_EVALUATE_UNSUPPORTED_FUNCTION`.

## Query Recipes

Recipes are non-normative examples that exercise multiple query features together. They are useful as implementation and workbench smoke tests.

Dynamic address literals can parameterize source, predicate, ordering, and projection:

```text
from path($.<"params">.source)
where isValue(path($.<"params">.statusField)) and path($.<"params">.statusField) == "active"
order by path($.<"params">.sortField) asc
select path($.<"params">.field)
```

`isValue(...)`, `exists(...)`, and explicit null predicates can distinguish concrete values, explicit nulls, and missing bindings:

```text
from $.inventory.items.*
where isValue(.status) or (exists(.status) and isNull(.status))
select { sku = .sku status = fallback(.status, "missing") }
```

`resolveChild(...)` and `fallback(...)` can compose inside projections:

```text
from $.inventory.items.*
where .qty >= 4
select { sku = .sku category = resolveChild($.inventory.categoryLabels, .category) status = fallback(.status, "missing") }
```

Experimental `SANSA.Transform` helpers can construct row-shaped objects from table-like positional data. `objectFrom(...)` pairs all fields:

```text
from $.table.content.*
select objectFrom($.table.header.*, .*)
```

`fieldsFrom(...)` selects a subset of row-shaped fields:

```text
from $.table.content.*
select fieldsFrom($.table.header.*, .*, "age")
```

Currently rejected with explicit diagnostics:

- unsupported function names
- invalid built-in function arity or argument types
- cardinality expressions that do not contain a supported binding-set predicate
- cross-type comparisons
- missing scalar values in scalar context
- multiple bindings in scalar context

Query results:

```js
{
  type: "queryResult",
  address,
  candidateAddress,
  valueAddress,
  kind,
  binding,
  value
}
```

`address` is a backwards-compatible alias for `candidateAddress`. `candidateAddress` is optional and records the canonical source address of the candidate binding when the namespace exposes one. It is the address selected by `from`, after `where`, ordering, and slicing.

An address is a locator in the namespace's current structure, not a durable
identity. Positional addresses can change when ordered containers are edited.
When a host supplies `binding.identity`, SANSA treats it as opaque structural
occurrence metadata; it does not substitute identity for addressing. Mutation
adapters can use identity and observed-state preconditions to reject stale
targets.

`valueAddress` is present only when projection preserves one existing selected binding identity. For example, `from $.items.* select .sku` can carry `candidateAddress = $.items[0]` and `valueAddress = $.items[0].sku`. If the selected value is a multi-binding Binding Set, each binding retains its own address inside the value instead of collapsing to one `valueAddress`.

`kind` is `binding` when the selected value is a Binding Set that preserves existing namespace binding identity. `valueAddress` is still present only for the single-binding case. `kind` is `derived` for constructed objects and scalar function results. Derived values do not become addressable namespace bindings.

Query values:

```js
{ type: "scalar", value }
{ type: "bindingSet", bindings }
{ type: "object", value }
```

Bindings expose scalar values through `namespace.value(binding)`, `binding.value`, or `binding.scalar`.

The built-in evaluator compares finite numeric lexemes exactly. A namespace may
still expose a JavaScript `number` as its convenience value, but should also
expose `numericLexeme` so equality and ordering do not inherit host-number
precision loss. Projection materialization remains the namespace adapter's
policy: lossless adapters can expose canonical numeric strings, while adapters
that deliberately expose native numbers should document that conversion.
Numeric literals written directly in a query are projected as their canonical
string lexeme so the evaluator does not round them before returning a result.
Invalid comparisons identify the two evaluator categories (for example,
`string vs finiteNumber`) and include `candidateAddress` when evaluation was
attached to a candidate binding.

The evaluator does not execute host-supplied functions. Function support is limited to the built-ins listed above.

SANSA query evaluation is bounded, deterministic, in-process evaluation over a
host-supplied namespace. It is not a persistent database: the package does not
provide storage, indexes, transactions, or a cost-based query optimizer. Hosts
remain responsible for namespace lifecycle, authorization, and durable writes.

## Qualifier Model

```js
{
  type: "QualifierExpression",
  terms: [QualifierTerm]
}
```

```js
{
  type: "QualifierTerm",
  name,
  parameters,
  parameterGroups,
  arguments
}
```

Arguments are one of:

```js
{ kind: "token", value }
{ kind: "quoted", value }
{ kind: "number", value }
```

Top-level qualifier unions are represented by multiple `terms`. Nested qualifier unions inside generic parameters are rejected.

Qualifier terms may contain zero or more parameter groups and zero or one clarifier value list:

```text
name<parameter,parameter><parameter>[argument,argument]
```

`parameters` is a flattened convenience view. `parameterGroups` preserves how the term should render. Clarifier values preserve AEON's single-list datatype clarifier grammar.

## Canonical Rendering

Canonical rendering:

- preserves `$` and `?` root kind
- renders identifier-safe members as `.name`
- renders other member names as `.["..."]`
- renders parent traversal as `.^`
- renders local spaces as `.<"...">`
- renders name patterns as `.("...")`
- renders quoted payload escapes using AEON double-quoted string escape forms
- renders qualifier unions without spaces, for example `number|nan`
- renders qualifier parameters without spaces, for example `list<string>`
- preserves repeated qualifier parameter groups, for example `tuple<x><y>`
- renders quoted qualifier arguments when the argument was parsed as quoted

## Current Error Codes

- `SANSA_EMPTY_ADDRESS`
- `SANSA_EXPECTED_ROOT`
- `SANSA_EXPECTED_TOKEN`
- `SANSA_EXPECTED_IDENTIFIER`
- `SANSA_EXPECTED_INDEX`
- `SANSA_EXPECTED_QUALIFIER`
- `SANSA_EXPECTED_QUALIFIER_ARGUMENT`
- `SANSA_UNEXPECTED_CHARACTER`
- `SANSA_UNEXPECTED_WHITESPACE`
- `SANSA_TRAILING_INPUT`
- `SANSA_EMPTY_MEMBER_NAME`
- `SANSA_EMPTY_LOCAL_SPACE_NAME`
- `SANSA_LEADING_ZERO_INDEX`
- `SANSA_POSITION_INDEX_LIMIT_EXCEEDED`
- `SANSA_INVALID_QUALIFIER`
- `SANSA_INVALID_QUALIFIER_ARGUMENT`
- `SANSA_INVALID_QUALIFIER_ARGUMENT_CHAR`
- `SANSA_RAW_NEWLINE_IN_QUOTED_PAYLOAD`
- `SANSA_UNTERMINATED_QUOTED_PAYLOAD`
- `SANSA_UNTERMINATED_ESCAPE`
- `SANSA_INVALID_ESCAPE`
- `SANSA_UNTERMINATED_UNICODE_ESCAPE`
- `SANSA_INVALID_UNICODE_ESCAPE`
- `SANSA_INVALID_UNICODE_SCALAR`
- `SANSA_QUERY_EMPTY`
- `SANSA_QUERY_EXPECTED_FROM`
- `SANSA_QUERY_EXPECTED_SELECT`
- `SANSA_QUERY_SELECT_MUST_BE_TERMINAL`
- `SANSA_QUERY_DUPLICATE_CLAUSE`
- `SANSA_QUERY_INVALID_CLAUSE_ORDER`
- `SANSA_QUERY_UNTERMINATED_BLOCK_COMMENT`
- `SANSA_QUERY_EXPECTED_FROM_ADDRESS`
- `SANSA_QUERY_INVALID_FROM_ADDRESS`
- `SANSA_QUERY_INVALID_FROM_SOURCE`
- `SANSA_QUERY_EXPECTED_WHERE_EXPRESSION`
- `SANSA_QUERY_EXPECTED_SELECT_EXPRESSION`
- `SANSA_QUERY_EXPECTED_ORDER_EXPRESSION`
- `SANSA_QUERY_INVALID_OFFSET`
- `SANSA_QUERY_INVALID_LIMIT`
- `SANSA_QUERY_EXPECTED_EXPRESSION`
- `SANSA_QUERY_UNEXPECTED_EXPRESSION_TOKEN`
- `SANSA_QUERY_UNTERMINATED_EXPRESSION`
- `SANSA_QUERY_INVALID_NUMBER_LITERAL`
- `SANSA_QUERY_INVALID_SYMBOL_LITERAL`
- `SANSA_QUERY_INVALID_RESOLUTION_EXPRESSION`
- `SANSA_QUERY_INVALID_FUNCTION_CALL`
- `SANSA_QUERY_INVALID_PROJECTION`

## Current Query Evaluate Error Codes

Evaluation diagnostics may also include context fields such as `phase`, `candidateAddress`, `extension`, `budget`, `limit`, and `observed`. These fields are context, not distinct error categories.

- `SANSA_QUERY_POLICY_VIOLATION`
- `SANSA_QUERY_BUDGET_EXCEEDED`
- `SANSA_QUERY_EVALUATE_UNSUPPORTED_FUNCTION`
- `SANSA_QUERY_EVALUATE_UNSUPPORTED_EXTENSION`
- `SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL`
- `SANSA_QUERY_EVALUATE_UNSUPPORTED_EXPRESSION`
- `SANSA_QUERY_EVALUATE_EXPECTED_BOOLEAN`
- `SANSA_QUERY_EVALUATE_EXPECTED_SCALAR`
- `SANSA_QUERY_EVALUATE_MISSING_SCALAR`
- `SANSA_QUERY_EVALUATE_CARDINALITY`
- `SANSA_QUERY_EVALUATE_INVALID_COMPARISON`
- `SANSA_QUERY_EVALUATE_INVALID_FROM_SOURCE`
- `SANSA_QUERY_EVALUATE_INVALID_PATH_LITERAL`
- `SANSA_QUERY_EVALUATE_INVALID_EXISTENCE_ARGUMENT`
- `SANSA_QUERY_EVALUATE_INVALID_CARDINALITY_ARGUMENT`

## Current Resolve Error Codes

- `SANSA_RESOLVE_EXPECTED_NAMESPACE`
- `SANSA_RESOLVE_MISSING_ROOT`
- `SANSA_RESOLVE_UNSUPPORTED_CONTEXTUAL_ROOT`
- `SANSA_RESOLVE_UNSUPPORTED_ATTRIBUTE_SPACE`
- `SANSA_RESOLVE_UNSUPPORTED_LOCAL_SPACE`
- `SANSA_RESOLVE_UNSUPPORTED_PARENT`
- `SANSA_RESOLVE_PARENT_TRAVERSAL_FORBIDDEN`
- `SANSA_RESOLVE_BOUNDARY_ESCAPE_FORBIDDEN`
- `SANSA_RESOLVE_EXACT_MULTIPLICITY_VIOLATION`
- `SANSA_RESOLVE_UNSUPPORTED_SELECTOR`

## Host-token step parsing

The supported [selector cursor subpath](selector-cursor.md) shares native grammar with token-based hosts. It does not broaden reference eligibility or the root exports.

## Experimental child identity candidate

The implementation-local `sansa.resolve.child-identity.candidate.v1` metadata advertises JavaScript standalone parser/render/Resolve only. See [candidate contract](child-identity-candidate.md). It is not a new normative registry allocation, a released feature claim, or Rust/Python parity. Query, activation, AEOS rules, Instruction, mutation, SO, identity references and recursive extensions remain unadmitted.

Run the experimental candidates explicitly with `npm run cts:address:child-identity` and `npm run cts:resolve:child-identity`, setting `AEONITE_CTS_ROOT` to the owning CTS directory when needed. Default CTS commands retain their existing targets. The Resolve fixture adapter exposes an identity accessor only for `supportsIdentity: true` and verifies actual accessor-call counts; metadata fields alone do not grant capability.


The child-identity candidate exposes optional `SansaResolveDiagnostic.identity` for authored selector context on identity-related Resolve failures. Read-only rollout preparation may proceed with the unresolved JavaScript heap qualification explicitly deferred; this is not a released support or cost-pass claim. See [candidate delivery status](child-identity-candidate.md).

## Candidate Query identity admission

Query source addresses and resolution expressions support direct child identity
selection over explicitly capable namespaces. Candidate/value addresses remain
canonical structural paths; selected bindings are original namespace handles.
The existing `resolve.maxIdentityInspections` option is a whole-Query budget
(default 10,000), shared across every clause, candidate and repeated read. Each
invocation owns fresh private state; caller options are never mutated or used as
a session. Any failure returns no records. Binding/result limits remain separate.
Dynamic `path(...)` identity activation now has its own [constrained feature and
scope contract](child-identity-activation.md). Trusted/default activation, reference
following, graph traversal, Instruction and mutation retain their guards. Public Rust `evaluate_expression` remains
closed for mutation-precondition consumers; only Query entry points admit IDs.
No public struct, session, codec or serialization format is added by this slice.
