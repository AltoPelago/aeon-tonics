# SANSA Query Tool

The package includes a standalone query tool for exercising SANSA.Query against
AEON source, portable Telex AES, reader-only Film AES, or a host-neutral JSON
namespace fixture:

```bash
npm run query -- --query 'from $.inventory.items.* where contains(.sku, "B") select .sku'
npm run query -- --format json --query 'from $.inventory.items.* where any(.roles.* == "admin") select { sku = .sku name = .name }'
npm run query -- --query-file query.sansaq --fixture fixtures/query-inventory.aeon
npm run query -- --query-file query.sansaq --fixture fixtures/query-inventory.telex.aes
npm run query -- --query-file query.sansaq --fixture fixtures/query-inventory.json
npm run query -- --policy validation --query 'from $.inventory.items.* where .qty >= 4 select .sku'
npm run query -- --disable-transform --query 'from $.table.content.* select objectFrom($.table.header.*, .*)'
npm run query -- --max-from-bindings 3 --query 'from $.inventory.items.* select .sku'
npm run query -- --value-semantics fr --query 'from $.inventory.items.* order by .name asc select .name'
npm run query -- --params '{"source":{"type":"SansaAddressLiteral","address":"$.inventory.items[3]"},"field":{"type":"SansaAddressLiteral","address":"?.sku"}}' --query 'from path($.<"params">.source) select path($.<"params">.field)'
```

Text output uses an AEON-like value renderer for readability, including
explicit null reasons such as `!notSet`. JSON output remains the structured
machine-readable result envelope.

The default CLI fixture is [../fixtures/query-inventory.json](../fixtures/query-inventory.json),
which keeps `sansa-query` self-contained after package install. `.aeon`
fixtures are compiled with an optional AEON TypeScript Core runtime and adapted
into a SANSA resolver namespace; JSON fixtures expose bindings with `address`,
`children`, optional `attributeSpace` or `attributes`, optional `localSpaces`,
and scalar values through `value` or `scalar`.

`.telex.aes` fixtures are parsed and validated with an optional AEON AES
runtime, then adapted directly from the complete portable event stream. The
adapter preserves record order, flat attribute spaces, structural occurrence
identity, datatype components, and the explicit `NodeLiteral` → `NodeHead` →
content hierarchy. Partial streams are rejected because this tool has no
external namespace state with which to complete them.

`.film.aes` fixtures are decoded from bytes by the same optional AES runtime
and then use the identical portable-record adapter. The CLI accepts Film only
as complete query input. It does not expose Film mutation, re-encoding, or a
durable writer.

To create and query the minimal Film v1 scalar used by the test suite:

```bash
node --input-type=module -e "import { writeFileSync } from 'node:fs'; writeFileSync('scalar.film.aes', Buffer.from('4f5f5fff010012000109242e6d6573736167650568656c6c6f', 'hex'))"
npm run query -- --query 'from $.message select .' --fixture scalar.film.aes
```

AEON fixture support is optional so SANSA can remain a lower-level package. For
published-package use, install `@altopelago/aeon-core` in the calling project or
set `SANSA_AEON_CORE_MODULE` to an AEON Core module path or specifier. Inside
the aeon-family development workspace, the tool also falls back to the sibling
AEON TypeScript build path.

Telex fixture support follows the same optional-integration model. Install
`@altopelago/aeon-aes`, set `SANSA_AEON_AES_MODULE`, or use the sibling AES
TypeScript build in the aeon-family development workspace.

The CLI can also mount JSON params at `$.<"params">` using `--params` or
`--params-file`. Params may be supplied as a full fixture binding with
`children`, or as a simple object map. Structured SANSA Address Literal values
use `{ "type": "SansaAddressLiteral", "address": "..." }` and become usable
through `path(...)`.

Use `--policy validation` to exercise the proposal-stage validation policy from
the CLI. Use `--disable-transform` to run normal Query evaluation with
experimental `SANSA.Transform` helpers disabled.

Use `--value-semantics <profile>` to select an explicit query value-semantics
profile. The current implementation recognizes `default`,
`aeon.value.default.v1`, `aeon.value.string.codepoint.v1`,
`aeon.value.string.natural.ascii.v1`, `fr`, `fr-FR`, and
`aeon.value.string.locale.fr.v1`; other compact locale tags are passed to
the host Intl collation surface as implementation-slice behavior.

Host callers can pass optional `evaluateQuery(..., { budget: ... })` limits for
pipeline sizes such as `maxFromBindings`, `maxWhereCandidates`,
`maxOrderCandidates`, and `maxResultRecords`. The CLI exposes the same surface
through `--max-from-bindings`, `--max-where-candidates`,
`--max-order-candidates`, and `--max-result-records`. Budget exhaustion reports
`SANSA_QUERY_BUDGET_EXCEEDED` and returns no partial result set.

## Browser Workbench

For browser-based testing against `.aeon`, `.telex.aes`, or JSON fixture input,
run the technical workbench:

```bash
npm run query:web
```

Then open `http://127.0.0.1:4173/tools/query-web/`.

Film remains a byte-oriented CLI and direct runtime input in this release; the
browser workbench does not convert Film bytes into its JSON request envelope.

The same server also exposes the experimental SANSA Mutate Workbench at
`http://127.0.0.1:4173/tools/mutate-web/`. The Mutate Workbench uses `.aeon` or
complete `.telex.aes` source input plus an editor that can accept structured JSON mutation requests
or proposal-stage SANSA Instruction source. Structured JSON runs
`planMutation(...)` directly. Instruction source runs `planInstruction(...)`,
then uses the returned plan for the same apply preview path. Each request runs
against a fresh in-memory namespace.

Telex apply is intentionally limited to exact scalar replacement. Successful
apply re-emits a complete portable stream while preserving event ordering,
paths, identities, datatype components, and separate attributes. It removes
stale origin/span coordinates from the changed event. Structural rewrites are
rejected until their portable path and reference rewriting rules are defined.

For command-line testing of proposal-stage SANSA.Instruction, use the
standalone Instruction tool:

```bash
npm run instruction -- --mode plan --instruction $'from $.inventory.items.*\nwhere .sku == "B-200"\nreplace .qty with :int32, 10'
```

It uses the same default JSON fixture as the Query CLI and can also load AEON
fixtures. See [instruction-tool.md](instruction-tool.md) for details.

The workbench defaults to [../fixtures/query-inventory.aeon](../fixtures/query-inventory.aeon),
derives a SANSA resolver namespace from the optional AEON TypeScript Core
runtime, and runs SANSA.Query over that derived graph. Telex mode uses the
portable AES adapter described above. It also includes a params
local-space editor mounted at `$.<"params">`, a Normal/Validation policy toggle,
a Transform extension toggle, a value-semantics profile selector, optional
budget limit inputs, plus Telex and JSON fixture modes for testing portable and
host-shaped resolver input directly.

In text mode, failed parses and evaluations render compact diagnostic lines
with phase and candidate context when available. JSON mode exposes the full
diagnostic payload. Inspect mode renders a scan-friendly view of candidate
addresses, projected values, selected binding addresses, and binding metadata.

Workbench examples live in [../tools/query-web/examples.mjs](../tools/query-web/examples.mjs).
The browser UI renders the grouped example menu from that catalog, and the
runtime tests execute the same examples against the default `.aeon` fixture
when an AEON runtime is available.

## Child identity selectors (candidate)

Read-only Query sources and address expressions accept child identity selectors
when the namespace explicitly exposes identity inspection:

```sansa
from $.items.\first\
select .\label\
```

The selected candidate and value retain their canonical structural paths and
original binding handles. `resolve.maxIdentityInspections` (default 10,000)
is one logical inspection budget for the entire Query invocation, including
`from`, `where`, ordering, projection fields, all candidates and repeated reads.
A miss still costs inspections; a failure returns no partial records. Enumeration
and metadata costs depend on the host adapter. Calls have independent budgets.

Dynamic `path(...)` identity activation requires the separate explicit constrained
feature and scope contract in [identity activation](child-identity-activation.md).
Trusted/default activation, references, Instruction and mutation stay guarded. Pure Python exposes Address/Resolve without a Query evaluator. The existing
native Pytonic `Document.query` facade uses the shared Rust Query engine and
its default 10,000-inspection budget; it adds no new method or keyword argument.

## Query Semantics

Boolean context accepts explicit Boolean scalar values and single resolved
bindings that expose a Boolean scalar; it does not use host-language truthiness.
Boolean `not` negates Boolean expressions. Boolean `and` and `or` evaluate left
to right and short-circuit, so guard predicates can protect later scalar
comparisons from missing or incompatible bindings.

Existence predicates inspect whether a resolution expression resolves any
bindings. `exists(...)` returns true when one or more bindings are present, and
`absent(...)` returns true when no bindings are present.

```text
where exists(.roles) and absent(.roles.*)
```

Explicit null values are bindings, not missing data. Use `isNull(...)` or
`isNullReason(...)` to test null values after guarding for presence:

```text
where exists(.status) and isNullReason(.status, "notSet")
```

NaN and infinity are explicit numeric special values. Use `isNaN(...)` and
`isInfinity(...)` for literal-form tests; `NaN` is rejected by scalar comparison
and ordering.

`isValue(...)` is a missing-aware concrete-value guard. It returns true for one
concrete value, including finite numbers, infinities, strings, Booleans,
lexical structured scalars, SANSA address literals, legal reference forms, and
containers. It can inspect scalar expressions directly or a Binding Set produced
by resolution or `path(...)`. It returns false for missing bindings, explicit
null, explicit absence values, and NaN, while multiple bindings remain a
cardinality error.

The current evaluator allows same-type number and string comparisons, Boolean
equality, exact toggle-token equality, same-family lexical value equality for
hex, radix, encoding, and separator values, exact reference-form equality,
same-kind structural container equality, and infinity as a numeric bound.
Query source can express the same AEON scalar literal families directly, for
example `#ff00aa`, `%ff00aa`,
`&QmFzZTY0IQ==`, `^0.11.0`, `!notSet`, and temporal-looking literals such as
`2026-`, `2026-07`, `2026-07-25`, `09:30:00Z`, `2026-07-25T09:30:00Z`, and
`2026-07-25T09:30:00Z&Australia/Melbourne`. Same-family temporal values compare
through the active temporal value-semantics profile; the default profile uses
canonical payload order for presentation and does not claim chronological
ordering. `compareTemporalClaims(left, right)` and the `temporalRelation`
operation expose conservative completion-set relations: `equal`, `before`,
`after`, `contains`, `containedBy`, `overlaps`, or `incomparable`. They do not
resolve named zones, local context, non-UTC timescales, unknown `-00:00`
offsets, or leap-second chronology. The evaluator rejects mixed-type
comparisons, toggle-to-Boolean coercion, hex-to-radix coercion, cross-family
temporal comparison, Boolean ordering, container ordering, explicit null
comparison, and NaN comparison.

Queries can request the same completion-set relation with
`temporalRelation(left, right)`. Both arguments must resolve to one temporal
scalar or be temporal literals. The function returns one of the relation names
above as a string, so it can be projected or used in a predicate:

```text
from $.schedule
where temporalRelation(.window, 10:30Z) == "contains"
select { window = .window relation = temporalRelation(.window, 10:30Z) }
```

Reduced-granularity dates use the same completion-set rules. For example,
`temporalRelation(2026-, 2026-07)` and
`temporalRelation(2026-07, 2026-07-25)` are both `contains`.

Numeric datatype labels such as `int32`, `uint64`, and `float64` remain visible
to semantic filters. When the host exposes their payload as a finite numeric
value, comparison uses the shared numeric value semantics; range, width,
integer-only, unsigned, and precision checks remain profile or schema concerns.
The same label-vs-family split applies to reserved aliases: `n` compares as a
number, `bool` compares as a Boolean, `trimtick` and `prose` compare as strings,
`radix2`, `radix6`, `radix8`, and `radix12` remain radix-family labels,
`base64`, `embed`, and `inline` compare as encoded payloads, and `kadot`
compares as a separator payload when the host exposes those representation
families. `hex` remains distinct from radix, including `radix[16]`; no numeric
or byte-level interpretation is implied without an explicit profile.
Use `--value-semantics radix-numeric` (full id
`aeon.value.radix.numeric.same-base.v1`) to enable exact numeric equality and
ordering for radix-family operands with the same resolved base. The typed
operand may supply the base for an untyped `%...` query literal. The profile
does not enable cross-base comparison, and the default profile continues to
preserve radix representation identity.
Use `--value-semantics radix-numeric-cross-base` (full id
`aeon.value.radix.numeric.cross-base.v1`) when both radix operands declare
different bases and exact mathematical comparison is intended. The profile
uses exact rational comparison, so base-2 `%.1` equals base-10 `%.5`, while
base-3 `%.1` is greater than the finite decimal approximation `%.333`.
Semantic filters match the base datatype label of generic claims, so
`#null`, `#nan`, and `#infinity` can select values annotated as `null<T>`,
`nan<T>`, and `infinity<T>` before predicates such as `isNullReason(...)`,
`isNaN(...)`, or `isInfinity(...)` inspect the value.

Container equality compares one resolved container binding on each side.
Objects compare by member names and member values. Lists, tuples, and nodes
compare by child order. Container kinds are not coerced, so a list and a tuple
with identical child values still do not compare equal.
Container datatype labels remain visible to semantic filters, including
`#object`, object aliases such as `#obj`, `#o`, and `#envelope`, generic bases such as
`#list` for `list<T>`, plus `#tuple` and `#node`. These filters select
bindings; they do not change structural comparison or introduce container
ordering.
Container representation filters such as `%object`, `%list`, `%tuple`, and
`%node` select by exposed shape instead of datatype claim. For example,
`%object` can select both `obj` and `envelope` bindings when both expose object
representation.

```text
where .consent == yes
```

AEON toggle literal spellings `yes`, `no`, `on`, and `off` are parsed as toggle
values. They are not Boolean aliases: `yes` does not equal `on`, and `yes` does
not equal `true` without an explicit conversion or profile-defined comparison
domain.

Membership tests a scalar against the scalar values exposed by a Binding Set:

```text
where "admin" in .roles.*
```

The left operand must resolve to one scalar. The right operand must be a Binding
Set; empty and non-matching sets evaluate to false. Each right-side binding is
compared using equality comparison rules, so incompatible values, explicit
nulls, and NaN fail instead of being skipped.

Ordinary string functions consume single scalar string arguments. The current
built-ins are `contains`, `startsWith`, `endsWith`, `lower`, `upper`, and
`concat`. Function-name matching is case-sensitive. They fail on missing
bindings, multiple bindings, explicit null, numeric specials, and other
non-string values unless a specific function contract says otherwise.

`radixScale(value)` is the non-string built-in for radix representation
metadata. It returns the number of fractional radix digits excluding `_`
separators, so `radixScale(%19.9900)` is `4` while
`radixScale(%19.99)` is `2`. It does not select a numeric comparison profile
or change equality.

`temporalRelation(left, right)` is the non-string built-in for conservative
completion-set relations between two temporal values.

String comparison and `order by` use deterministic Unicode scalar-value
ordering by default. They do not use host locale or process locale collation
unless an embedding caller supplies an explicit value-semantics profile.
For exploratory testing, the CLI and browser workbench can select the French
profile to compare locale-aware behavior against the default codepoint order, or
the Natural ASCII profile to compare numeric-region behavior such as
`part-2 < part-10`. These string profiles do not reinterpret `hex`, `radix`,
`encoding`, `separator`, or `sansa` values as richer domains; those require an
explicit future profile or consumer contract.

`path(value)` activates a structured SANSA Address Literal value. In expression
positions such as `select`, `where`, and `order by`, it resolves in the current
candidate context and returns a Binding Set. In `from path(...)`, it supplies
the source Binding Set for the query. It does not parse plain strings as
addresses.

Library callers must explicitly authorize dynamic activation with either
`addressActivation: "trusted"` or a constrained policy containing structural
`allowedRoots`, selector capabilities, contextual-root permission, and optional
depth and binding limits. The CLI and browser workbench deliberately use trusted
activation because they are local fixture-testing tools. Applications accepting
queries or Address values from another trust boundary should use a constrained
policy or a pre-scoped namespace view.
SANSA Address Literal values remain selectable as values with `#sansa` and
`%sansa`; those filters do not activate the address. Activation is always
explicit through `path(...)`.

`fallback(primary, replacement)` handles missing primary values only. The
replacement expression is evaluated only when the primary expression resolves no
scalar value; explicit null, cardinality, type, and comparison errors remain
fail-fast.

`resolveChild(base, key)` resolves a dynamic direct member or position from one
addressable base container. String keys select members; non-negative integer
keys select positions. A missing target returns an empty Binding Set, and the
consuming expression decides whether that is acceptable. It does not parse
traversal strings or perform collection joins.

`follow(reference)` explicitly traverses an AEON reference form to its target
binding for read-only evaluation. Without `follow(...)`, reference forms compare
by reference kind and canonical target path only. With `follow(...)`, the
followed target value is consumed by ordinary value semantics:

Concrete reference forms remain visible to representation filters such as
`%cloneReference` and `%pointerReference`. These filters select the reference
binding itself; they do not follow, clone, inline, or otherwise materialize the
target.

```text
from $.targetClone
where follow(.) == 7
select follow(.)
```

`objectFrom(keys, values)` is an experimental transform-library helper. It
pairs two ordered Binding Sets by position and constructs a derived object. Key
bindings must expose unique string scalar values, value bindings must expose
scalar values, and mismatched lengths fail with a cardinality diagnostic.

`fieldsFrom(keys, values, field, ...)` is an experimental transform-library
helper. It uses the same ordered pairing model as `objectFrom`, then returns
only the requested string-named fields.

Semantic and representation filters can be used as comparison guards. This
keeps mixed-type or missing bindings out of scalar comparisons:

```text
where exists(.id#number) and .id > 2
```

Cardinality operators follow conventional quantified logic. `any(...)` requires
at least one match, `all(...)` is true when every resolved binding matches, and
`none(...)` is true when no resolved binding matches. Empty Binding Sets
therefore evaluate as `any(empty) = false`, `all(empty) = true`, and
`none(empty) = true`.

To require a non-empty set where every binding matches, combine `any(...)` and
`all(...)` explicitly:

```text
where any(.roles.* == "admin") and all(.roles.* == "admin")
```

The name `only(...)` is not part of the current evaluator surface; it remains a
possible future shorthand for this non-empty-all pattern.

## Recipes

Scalar params mounted in the `params` local space can be compared directly.
Local-space names use quoted selector syntax:

```text
from $.inventory.items.*
where .name == $.<"params">.name
select .sku
```

SANSA Address Literal params are activated with `path(...)` before resolution:

```text
from path($.<"params">.source)
where isValue(path($.<"params">.statusField)) and path($.<"params">.statusField) == "active"
order by path($.<"params">.sortField) asc
select path($.<"params">.field)
```

```text
from $.inventory.items.*
where isValue(.status) or (exists(.status) and isNull(.status))
select { sku = .sku status = fallback(.status, "missing") }
```

```text
from $.inventory.items.*
where .qty >= 4
select { sku = .sku category = resolveChild($.inventory.categoryLabels, .category) status = fallback(.status, "missing") }
```

```text
from $.table.content.*
select objectFrom($.table.header.*, .*)
```

```text
from $.table.content.*
select fieldsFrom($.table.header.*, .*, "age")
```

The table-row helpers above are experimental `SANSA.Transform` extensions, not
required SANSA.Query core behavior.
